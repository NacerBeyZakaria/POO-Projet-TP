import java.time.LocalDateTime;
import java.util.List;

public class Medecin {
    private static long idCounter = 1;
    private long id;
    private String nom;
    private String prenom;
    private String specialite;
    private String telephone;
    private String email;

    public Medecin(String nom, String prenom, String specialite, String telephone, String email) {
        this.id = idCounter++;
        this.nom = nom;
        this.prenom = prenom;
        this.specialite = specialite;
        this.telephone = telephone;
        this.email = email;
    }

    // Getters

    public long getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getSpecialite() {
        return specialite;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getEmail() {
        return email;
    }

    @Override
    public String toString() {
        return "Médecin ID: " + id +
                ", Nom: " + nom +
                ", Prénom: " + prenom +
                ", Spécialité: " + specialite +
                ", Téléphone: " + telephone +
                ", Email: " + email;
    }

    /**
     * Vérifie si le médecin est disponible à la date et l'heure spécifiées.
     *
     * @param dateHeure          La date et l'heure du rendez-vous.
     * @param rendezVousService  Le service de gestion des rendez-vous.
     * @return Vrai si disponible, faux sinon.
     */
    public boolean isAvailable(LocalDateTime dateHeure, RendezVousService rendezVousService) {
        List<RendezVous> rdvs = rendezVousService.getRendezVousParMedecin(this.id);
        for (RendezVous rdv : rdvs) {
            if (rdv.getDateHeure().equals(dateHeure) && rdv.getStatut().equalsIgnoreCase("Confirmé")) {
                return false;
            }
        }
        return true;
    }
}
