import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DossierMedicalService {
    private List<DossierMedical> dossiers = new ArrayList<>();

    public void ajouterDossierMedical(DossierMedical dossier) {
        dossiers.add(dossier);
        System.out.println("Dossier médical ajouté avec succès !");
    }

    public List<DossierMedical> getDossiersParPatient(long patientId) {
        List<DossierMedical> result = new ArrayList<>();
        for (DossierMedical dm : dossiers) {
            if (dm.getPatient().getId() == patientId) {
                result.add(dm);
            }
        }
        return result;
    }

    public Optional<DossierMedical> getDossierMedicalParId(long id) {
        return dossiers.stream().filter(d -> d.getId() == id).findFirst();
    }

    public void supprimerDossierMedical(long id) {
        dossiers.removeIf(d -> d.getId() == id);
        System.out.println("Dossier médical supprimé avec succès !");
    }
}
