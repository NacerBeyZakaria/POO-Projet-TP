import java.util.*;

public class PatientService {
    private List<Patient> patients = new ArrayList<>();

    public void ajouterPatient(Patient patient) {
        patients.add(patient);
        System.out.println("Patient ajouté avec succès !");
    }

    public List<Patient> getTousLesPatients() {
        return patients;
    }

    public Optional<Patient> getPatientParId(long id) {
        return patients.stream().filter(p -> p.getId() == id).findFirst();
    }

    public void supprimerPatient(long id) {
        patients.removeIf(p -> p.getId() == id);
        System.out.println("Patient supprimé avec succès !");
    }
}

