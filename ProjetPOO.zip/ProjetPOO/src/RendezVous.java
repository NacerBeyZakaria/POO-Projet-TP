import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


class RendezVous {
    private static long idCounter = 1;
    private long id;
    private Patient patient;
    private Medecin medecin;
    private LocalDateTime dateHeure;
    private String statut; // Confirmé, Annulé, etc.

    public RendezVous(Patient patient, Medecin medecin, LocalDateTime dateHeure, String statut) {
        this.id = idCounter++;
        this.patient = patient;
        this.medecin = medecin;
        this.dateHeure = dateHeure;
        this.statut = statut;
    }

    // Getters and Setters

    public long getId() {
        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public LocalDateTime getDateHeure() {
        return dateHeure;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    @Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return "RendezVous ID: " + id +
                ", Patient: " + patient.getNom() + " " + patient.getPrenom() +
                ", Médecin: " + medecin.getNom() + " " + medecin.getPrenom() +
                ", Date et Heure: " + dateHeure.format(formatter) +
                ", Statut: " + statut;
    }
}
