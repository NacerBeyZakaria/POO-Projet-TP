import java.util.*;

public class DossierMedical{
    private static long idCounter = 1;
    private long id;
    private Patient patient;
    private Medecin medecin;
    private String dateConsultation;
    private String observations;
    private String traitement;
    private List<String> ordonnances;
    private List<String> certificats;

    public DossierMedical(Patient patient, Medecin medecin, String dateConsultation,
                          String observations, String traitement) {
        this.id = idCounter++;
        this.patient = patient;
        this.medecin = medecin;
        this.dateConsultation = dateConsultation;
        this.observations = observations;
        this.traitement = traitement;
        this.ordonnances = new ArrayList<>();
        this.certificats = new ArrayList<>();
    }

    // Getters and Setters

    public long getId() {
        return id;
    }

    public Patient getPatient() {
        return patient;
    }

    public Medecin getMedecin() {
        return medecin;
    }

    public String getDateConsultation() {
        return dateConsultation;
    }

    public String getObservations() {
        return observations;
    }

    public String getTraitement() {
        return traitement;
    }

    public List<String> getOrdonnances() {
        return ordonnances;
    }

    public List<String> getCertificats() {
        return certificats;
    }

    public void ajouterOrdonnance(String ordonnance) {
        ordonnances.add(ordonnance);
    }

    public void ajouterCertificat(String certificat) {
        certificats.add(certificat);
    }

    @Override
    public String toString() {
        return "Dossier Médical ID: " + id +
                ", Patient: " + patient.getNom() + " " + patient.getPrenom() +
                ", Médecin: " + medecin.getNom() + " " + medecin.getPrenom() +
                ", Date Consultation: " + dateConsultation +
                ", Observations: " + observations +
                ", Traitement: " + traitement +
                ", Ordonnances: " + (ordonnances.isEmpty() ? "N/A" : ordonnances) +
                ", Certificats: " + (certificats.isEmpty() ? "N/A" : certificats);
    }
}


