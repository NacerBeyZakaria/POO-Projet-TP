public class Patient {
    private static long idCounter = 1;
    private long id;
    private String nom;
    private String prenom;
    private String telephone;
    private String adresse;
    private String dateNaissance;
    private double poids;
    private double taille;
    private String allergies;
    private String tares;

    public Patient(String nom, String prenom, String telephone, String adresse, String dateNaissance,
                   double poids, double taille, String allergies, String tares) {
        this.id = idCounter++;
        this.nom = nom;
        this.prenom = prenom;
        this.telephone = telephone;
        this.adresse = adresse;
        this.dateNaissance = dateNaissance;
        this.poids = poids;
        this.taille = taille;
        this.allergies = allergies;
        this.tares = tares;
    }

    // Getters

    public long getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public double getPoids() {
        return poids;
    }

    public double getTaille() {
        return taille;
    }

    public String getAllergies() {
        return allergies;
    }

    public String getTares() {
        return tares;
    }

    // Setters

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public void setDateNaissance(String dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public void setPoids(double poids) {
        this.poids = poids;
    }

    public void setTaille(double taille) {
        this.taille = taille;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    public void setTares(String tares) {
        this.tares = tares;
    }

    @Override
    public String toString() {
        return "Patient ID: " + id +
                ", Nom: " + nom +
                ", Prénom: " + prenom +
                ", Téléphone: " + telephone +
                ", Adresse: " + (adresse.isEmpty() ? "N/A" : adresse) +
                ", Date de Naissance: " + (dateNaissance.isEmpty() ? "N/A" : dateNaissance) +
                ", Poids: " + (poids > 0 ? poids + " kg" : "N/A") +
                ", Taille: " + (taille > 0 ? taille + " cm" : "N/A") +
                ", Allergies: " + (allergies.isEmpty() ? "N/A" : allergies) +
                ", Tares: " + (tares.isEmpty() ? "N/A" : tares);
    }
}
