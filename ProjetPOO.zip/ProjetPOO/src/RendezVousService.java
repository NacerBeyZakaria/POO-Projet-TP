import java.util.*;

public class RendezVousService {
    private List<RendezVous> rendezVousList = new ArrayList<>();

    public void prendreRendezVous(RendezVous rendezVous) {
        rendezVousList.add(rendezVous);
        System.out.println("Rendez-vous pris avec succès !");
    }

    public List<RendezVous> getRendezVousParMedecin(long medecinId) {
        List<RendezVous> result = new ArrayList<>();
        for (RendezVous rdv : rendezVousList) {
            if (rdv.getMedecin().getId() == medecinId) {
                result.add(rdv);
            }
        }
        return result;
    }

    public List<RendezVous> getRendezVousParPatient(long patientId) {
        List<RendezVous> result = new ArrayList<>();
        for (RendezVous rdv : rendezVousList) {
            if (rdv.getPatient().getId() == patientId) {
                result.add(rdv);
            }
        }
        return result;
    }

    public Optional<RendezVous> getRendezVousParId(long id) {
        return rendezVousList.stream().filter(r -> r.getId() == id).findFirst();
    }

    public void annulerRendezVous(long id) {
        rendezVousList.removeIf(r -> r.getId() == id);
        System.out.println("Rendez-vous annulé avec succès !");
    }
}