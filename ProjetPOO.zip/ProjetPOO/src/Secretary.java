import java.time.LocalDateTime;
import java.util.*;

class Secretary {
    private String name;
    private PatientService patientService;
    private MedecinService medecinService;
    private RendezVousService rendezVousService;

    public Secretary(String name, PatientService patientService, MedecinService medecinService, RendezVousService rendezVousService) {
        this.name = name;
        this.patientService = patientService;
        this.medecinService = medecinService;
        this.rendezVousService = rendezVousService;
    }

    /**
     * Ajoute un nouveau patient avec les détails de base.
     *
     * @param nom           Le nom de famille du patient.
     * @param prenom        Le prénom du patient.
     * @param telephone     Le numéro de téléphone du patient.
     * @param adresse       L'adresse du patient.
     * @param dateNaissance La date de naissance du patient.
     * @param poids         Le poids du patient.
     * @param taille        La taille du patient.
     * @param allergies     Les allergies du patient.
     * @param tares         Les tares ou handicaps du patient.
     * @return L'objet Patient nouvellement ajouté.
     */
    public Patient ajouterPatient(String nom, String prenom, String telephone, String adresse,
                                  String dateNaissance, double poids, double taille,
                                  String allergies, String tares) {
        Patient patient = new Patient(nom, prenom, telephone, adresse, dateNaissance, poids, taille, allergies, tares);
        patientService.ajouterPatient(patient);
        return patient;
    }

    /**
     * Planifie un rendez-vous si le médecin est disponible à la date et l'heure données.
     *
     * @param patientId L'ID du patient.
     * @param medecinId L'ID du médecin.
     * @param dateHeure La date et l'heure du rendez-vous.
     */
    public void prendreRendezVous(long patientId, long medecinId, LocalDateTime dateHeure) {
        Optional<Patient> patientOpt = patientService.getPatientParId(patientId);
        if (!patientOpt.isPresent()) {
            System.out.println("Patient non trouvé.");
            return;
        }

        Optional<Medecin> medecinOpt = medecinService.getMedecinParId(medecinId);
        if (!medecinOpt.isPresent()) {
            System.out.println("Médecin non trouvé.");
            return;
        }

        Medecin medecin = medecinOpt.get();
        if (!medecin.isAvailable(dateHeure, rendezVousService)) {
            System.out.println("Le médecin n'est pas disponible à ce créneau.");
            return;
        }

        // Par défaut, le statut est "Confirmé" lors de la prise d'un rendez-vous
        String statut = "Confirmé";
        RendezVous rdv = new RendezVous(patientOpt.get(), medecin, dateHeure, statut);
        rendezVousService.prendreRendezVous(rdv);

    }

    // Getters and Setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
