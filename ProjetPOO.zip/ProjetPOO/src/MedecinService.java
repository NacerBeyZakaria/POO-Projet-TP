import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MedecinService {
    private List<Medecin> medecins = new ArrayList<>();

    public void ajouterMedecin(Medecin medecin) {
        medecins.add(medecin);
        System.out.println("Médecin ajouté avec succès !");
    }

    public List<Medecin> getTousLesMedecins() {
        return medecins;
    }

    public Optional<Medecin> getMedecinParId(long id) {
        return medecins.stream().filter(m -> m.getId() == id).findFirst();
    }

    public void supprimerMedecin(long id) {
        medecins.removeIf(m -> m.getId() == id);
        System.out.println("Médecin supprimé avec succès !");
    }
}
